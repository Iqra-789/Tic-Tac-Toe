#include <iostream>
using namespace std;

// Global variable to represent the Tic Tac Toe board
char board[10] = { 'o','1','2','3','4','5','6','7','8','9' };

// Function to check the status of the game (win, draw, or in progress)
int check_win_status();

// Function to display the Tic Tac Toe board
void display_board();

int main()
{
    // Variables to keep track of the current player and their choice
    int current_player = 1, choice;
    char player_mark;

    // Main game loop
    do
    {
        // Display the current board state
        display_board();

        // Determine the current player
        current_player = (current_player % 2) ? 1 : 2;

        // Prompt the current player to make a move
        cout << "Player " << current_player << "'s turn, Enter a number:  ";
        cin >> choice;

        // Set the player's mark based on their number (X for player 1, O for player 2)
        player_mark = (current_player == 1) ? 'X' : 'O';

        // Check if the chosen cell is empty and within the valid range
        if (choice >= 1 && choice <= 9 && board[choice] == (choice + '0'))
            board[choice] = player_mark;
        else
        {
            // If the move is invalid, prompt the player to try again
            cout << "Invalid move. Please select an empty cell between 1 and 9." << endl;
            current_player--;
            cin.ignore();
            cin.get();
        }

        // Switch to the next player
        current_player++;
    } while (check_win_status() == -1); // Continue the loop until the game ends

    // Display the final board state
    display_board();

    // Determine the outcome of the game and display the result
    if (check_win_status() == 1)
        cout << "==>\aPlayer " << --current_player << " wins!" << endl;
    else
        cout << "==>\aGame draw!" << endl;

    // Wait for user input before exiting
    cin.ignore();
    cin.get();
    return 0;
}

// Function to check the status of the game (win, draw, or in progress)
int check_win_status()
{
    // Check all possible winning combinations and return the appropriate status
    if (board[1] == board[2] && board[2] == board[3])
        return 1;
    else if (board[4] == board[5] && board[5] == board[6])
        return 1;
    else if (board[7] == board[8] && board[8] == board[9])
        return 1;
    else if (board[1] == board[4] && board[4] == board[7])
        return 1;
    else if (board[2] == board[5] && board[5] == board[8])
        return 1;
    else if (board[3] == board[6] && board[6] == board[9])
        return 1;
    else if (board[1] == board[5] && board[5] == board[9])
        return 1;
    else if (board[3] == board[5] && board[5] == board[7])
        return 1;
    else if (board[1] != '1' && board[2] != '2' && board[3] != '3'
        && board[4] != '4' && board[5] != '5' && board[6] != '6'
        && board[7] != '7' && board[8] != '8' && board[9] != '9')
        return 0;
    else
        return -1;
}

// Function to display the Tic Tac Toe board
void display_board()
{
    // Clear screen and display game title
    system("cls");
    cout << "******************************************************" << endl;
    cout << "***************** Tic Tac Toe ***************** " << endl;
    cout << "******************************************************" << endl << endl;;

    // Display player marks legend
    cout << "X  for Player 1  \t\t\t O for Player 2 " << endl << endl;

    // Display the Tic Tac Toe board grid with player marks
    cout << "     |     |     " << endl;
    cout << "  " << board[1] << "  |  " << board[2] << "  |  " << board[3] << endl;
    cout << "_____|_____|_____" << endl;
    cout << "     |     |     " << endl;
    cout << "  " << board[4] << "  |  " << board[5] << "  |  " << board[6] << endl;
    cout << "_____|_____|_____" << endl;
    cout << "     |     |     " << endl;
    cout << "  " << board[7] << "  |  " << board[8] << "  |  " << board[9] << endl;
    cout << "     |     |     " << endl << endl;
}
